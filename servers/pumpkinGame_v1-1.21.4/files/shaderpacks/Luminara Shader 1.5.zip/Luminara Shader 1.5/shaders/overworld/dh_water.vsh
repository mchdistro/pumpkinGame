#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DH_WATER

#include "/program/luminara_programs/distant_water.glsl"
