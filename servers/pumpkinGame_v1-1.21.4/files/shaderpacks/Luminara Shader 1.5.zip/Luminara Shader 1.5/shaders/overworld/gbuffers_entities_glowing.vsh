#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define GBUFFERS_ENTITIES
#define GBUFFERS_ENTITIES_GLOWING

#include "/program/luminara_core/souls.glsl"
