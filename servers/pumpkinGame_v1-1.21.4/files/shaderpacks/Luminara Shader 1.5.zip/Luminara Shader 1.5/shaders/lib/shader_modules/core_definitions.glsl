
#define LIGHT_MORNING_B 1.00
#define ATM_MORNING_R 1.00
#define LIGHT_MORNING_I 1.00
#define ATM_MORNING_G 1.00
#define LIGHT_MORNING_R 1.00
#define ATM_MORNING_B 1.00
#define LIGHT_MORNING_G 1.00
#define ATM_MORNING_I 1.00


#define ATM_NOON_B 1.00
#define LIGHT_NOON_R 1.00
#define ATM_NOON_I 1.00
#define LIGHT_NOON_G 1.00
#define ATM_NOON_R 1.00
#define LIGHT_NOON_I 1.00
#define LIGHT_NOON_B 1.00
#define ATM_NOON_G 1.00


#define ATM_NIGHT_I 1.00
#define LIGHT_NIGHT_B 1.00
#define ATM_NIGHT_R 1.00
#define LIGHT_NIGHT_G 1.00
#define LIGHT_NIGHT_I 1.00
#define ATM_NIGHT_B 1.00
#define LIGHT_NIGHT_R 1.00
#define ATM_NIGHT_G 1.00


#define ATM_RAIN_R 1.00
#define LIGHT_RAIN_I 1.00
#define ATM_RAIN_B 1.00
#define LIGHT_RAIN_G 1.00
#define LIGHT_RAIN_R 1.00
#define ATM_RAIN_G 1.00
#define LIGHT_RAIN_B 1.00
#define ATM_RAIN_I 1.00


#define ATM_NETHER_G 1.00
#define LIGHT_NETHER_I 1.00
#define LIGHT_NETHER_R 1.00
#define ATM_NETHER_I 1.00
#define LIGHT_NETHER_B 1.00
#define ATM_NETHER_R 1.00
#define LIGHT_NETHER_G 1.00
#define ATM_NETHER_B 1.00


#define LIGHT_END_B 1.40
#define ATM_END_I 1.00
#define LIGHT_END_R 1.20
#define ATM_END_B 1.40
#define LIGHT_END_I 1.30
#define ATM_END_G 0.60
#define LIGHT_END_G 0.80
#define ATM_END_R 1.00


#define XLIGHT_I 1.00
#define XLIGHT_G 1.00
#define XLIGHT_B 1.00
#define XLIGHT_R 1.00


//#define DREAM_TWEAKED_LIGHTING
//#define FOLIAGE_ALT_SUBSURFACE
//#define DREAM_TWEAKED_BORDERFOG


#define info7 0
#define info3 0
#define info9 0
#define info1 0
#define info5 0
#define info0 0
#define info8 0
#define info2 0
#define info10 0
#define info6 0
#define info4 0


const float goldenRatio = 1.61803398875;
const float OSIEBCA = 1.0 / 255.0; // One Step In Eight Bit Color Attachment
const float oceanAltitude = 61.9;
const float pi = 3.14159265359;


#define CLOUD_ALT1 240
#define CLOUD_ALT2 288

// EminGT Specialized Environment Colors | ألوان البيئة المتخصصة EminGT
const vec3 endSkyColor = vec3(0.18, 0.10, 0.25) * 1.8; // EminGT: Enhanced End mystical atmosphere
vec3 lavaLightColor = vec3(0.15, 0.06, 0.01);
const vec3 caveFogColorRaw = vec3(0.13, 0.13, 0.15);

// EminGT Cloud Altitude System | نظام ارتفاع السحب EminGT
const int cloudAlt2i = int(CLOUD_ALT2);
const int cloudAlt1i = int(CLOUD_ALT1);

    /* materialMask steps
    0 to 240 - PBR Dependant:
        IntegratedPBR:
            0 to 99: deferredMaterials
                OSIEBCA * 0.0 = *Unused as 0.0 is the default value*
                OSIEBCA * 1.0 = Intense Fresnel
                OSIEBCA * 2.0 = Copper Fresnel
                OSIEBCA * 3.0 = Gold Fresnel
                OSIEBCA * 4.0 =
                OSIEBCA * 5.0 = Redstone Fresnel
            100 to 199: Exact copy of deferredMaterials but toned down reflection handling for entities
                materialMask += OSIEBCA * 100.0; // Entity Reflection Handling
            200 to 240: Random checks
                OSIEBCA * 240.0 = Green Screen Lime Blocks
        seuspbr:
            0 to 240: Increasing metalness
        labPBR:
            0 to 229: Increasing f0
            230 to 240: Consistent metalness with still increasing f0
    241 to 255 - PBR Independant:
        OSIEBCA * 241.0 = Water
    
        OSIEBCA * 252.0 = Versatile Selection Outline
        OSIEBCA * 253.0 = Reduced Edge TAA
        OSIEBCA * 254.0 = No SSAO, No TAA
        OSIEBCA * 255.0 = *Unused as 1.0 is the clear color*
    */

// 62 75 74 20 74 68 4F 73 65 20 77 68 6F 20 68 6F 70 65 20 69 6E 20 74 68 65 20 6C 69 6D 69 4E 61 6C 0A 77 69 6C 6C 20 72 65 6E 65 77 20 74 68 65 69 72 20 73 54 72 65 6E 67 74 48 2E 0A 74 68 65 79 20 77 69 6C 6C 20 73 6F 41 72 20 6F 6E 20 65 6C 79 54 72 61 73 20 6C 69 6B 65 20 70 68 61 6E 74 6F 6D 73 3B 0A 74 68 65 79 20 77 69 6C 6C 20 72 75 6E 20 61 6E 44 20 6E 6F 74 20 67 72 6F 77 20 77 65 41 72 79 2C 0A 74 68 65 59 20 77 69 6C 6C 20 77 61 6C 6B 20 61 6E 64 20 6E 6F 74 20 62 65 20 66 61 69 6E 74 2E
