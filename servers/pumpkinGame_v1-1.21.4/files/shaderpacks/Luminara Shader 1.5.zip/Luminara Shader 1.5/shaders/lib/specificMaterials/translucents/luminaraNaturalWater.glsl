// Luminara Natural Water
// Rebuilt surface model: crossed waves, depth absorption, restrained foam and Fresnel reflections.

vec3 luminaraBiomeTint = vec3(1.0);
vec3 luminaraWaterControl = vec3(1.0);

#if MC_VERSION >= 11300
    luminaraBiomeTint = sqrt(clamp(glColor.rgb, vec3(0.02), vec3(1.0)));

    #if WATER_STYLE >= 3
        vec3 luminaraBaseTint = mix(vec3(1.0), luminaraBiomeTint * vec3(0.92, 1.06, 1.10), 0.30);
        color.rgb = vec3(0.075, 0.305, 0.340) * luminaraBaseTint;
        // colorP is vec3 in terrain_solid (water cauldrons), so keep alpha from color.
        color.a = max(color.a, 0.08);
    #else
        color.rgb = pow2(colorP.rgb) * luminaraBiomeTint;
    #endif
#else
    #if WATER_STYLE >= 3
        color.rgb = vec3(0.075, 0.305, 0.340);
        color.a = max(color.a, 0.08);
    #else
        color.rgb = mix(color.rgb, vec3(GetLuminance(color.rgb)), 0.80);
        color.rgb = pow2(color.rgb) * vec3(2.2, 3.1, 3.0);
    #endif
#endif

#ifdef WATERCOLOR_CHANGED
    luminaraWaterControl = vec3(WATERCOLOR_RM, WATERCOLOR_GM, WATERCOLOR_BM);
    color.rgb *= luminaraWaterControl;
#endif

#define PHYSICS_OCEAN_INJECTION
#if defined GENERATED_NORMALS && (WATER_STYLE >= 2 || defined PHYSICS_OCEAN) && !defined DH_WATER
    noGeneratedNormals = true;
#endif

#if defined GBUFFERS_WATER || defined DH_WATER
    lmCoordM.y = min(lmCoord.y * 1.07, 1.0);

    float fresnel2 = pow2(fresnel);
    float fresnel4 = pow2(fresnel2);
    reflectMult = 1.0;

    #if WATER_MAT_QUALITY >= 3
        materialMask = OSIEBCA * 241.0;
    #endif

    vec3 worldPos = playerPos + cameraPosition;
    float luminaraWaterEvolution = frameTimeCounter * WATER_SPEED_MULT;
    float luminaraWaterTime = luminaraWaterEvolution * 0.012;
    float luminaraWaterScale = 0.032 * (float(WATER_SIZE_MULT) * 0.01);
    vec2 waterPos = (worldPos.xz + worldPos.y * vec2(0.37, 0.19)) * luminaraWaterScale;

    // Slowly evolving domain warping prevents a fixed texture from merely sliding over the sea.
    const mat2 luminaraWaterRotA = mat2(0.80, -0.60, 0.60, 0.80);
    const mat2 luminaraWaterRotB = mat2(0.36, 0.93, -0.93, 0.36);
    const mat2 luminaraWaterRotC = mat2(-0.71, 0.70, -0.70, -0.71);

    vec2 luminaraDriftA = luminaraWaterTime * vec2(0.78, 0.43)
                        + vec2(sin(luminaraWaterEvolution * 0.037), cos(luminaraWaterEvolution * 0.029)) * 0.10;
    vec2 luminaraDriftB = luminaraWaterTime * vec2(-0.38, 0.67)
                        + vec2(cos(luminaraWaterEvolution * 0.023), sin(luminaraWaterEvolution * 0.041)) * 0.09;
    vec2 luminaraDriftC = luminaraWaterTime * vec2(0.25, -0.92)
                        + vec2(sin(luminaraWaterEvolution * 0.031), cos(luminaraWaterEvolution * 0.047)) * 0.07;

    vec2 luminaraCoordA = luminaraWaterRotA * (waterPos * 2.35) + luminaraDriftA;
    vec2 luminaraCoordB = luminaraWaterRotB * (waterPos * 1.08) + luminaraDriftB;
    vec2 luminaraCoordC = luminaraWaterRotC * (waterPos * 5.70) + luminaraDriftC;

    vec2 normalMed = vec2(0.0);
    vec2 normalBig = vec2(0.0);
    vec2 normalSmall = vec2(0.0);
    vec2 luminaraDomainWarpA = vec2(0.0);
    vec2 luminaraDomainWarpB = vec2(0.0);

    #if WATER_STYLE >= 2
        vec2 luminaraWarpCoordA = luminaraWaterRotC * (waterPos * 0.38) + luminaraDriftC * 0.41;
        vec2 luminaraWarpCoordB = luminaraWaterRotA * (waterPos * 0.69) - luminaraDriftB.yx * 0.36 + 0.37;
        luminaraDomainWarpA = texture2D(gaux4, luminaraWarpCoordA).rg - 0.5;
        luminaraDomainWarpB = texture2D(gaux4, luminaraWarpCoordB).gr - 0.5;

        luminaraCoordA += luminaraWaterRotB * (luminaraDomainWarpA * 0.72 + luminaraDomainWarpB * 0.24);
        luminaraCoordB += luminaraWaterRotC * (luminaraDomainWarpB * 0.58 - luminaraDomainWarpA * 0.21);
        luminaraCoordC += luminaraWaterRotA * (luminaraDomainWarpA * 0.31 + luminaraDomainWarpB * 0.39);

        normalMed = texture2D(gaux4, luminaraCoordA).rg - 0.5;
        normalBig = texture2D(gaux4, luminaraCoordB).gr - 0.5;
        normalSmall = texture2D(gaux4, luminaraCoordC).rg - 0.5;

        vec2 luminaraEvolvingSlope = luminaraWaterRotA * luminaraDomainWarpA * 0.044
                                    + luminaraWaterRotB * luminaraDomainWarpB * 0.035
                                    + luminaraWaterRotC * normalBig * 0.024;

        vec3 normalMap = vec3(0.0, 0.0, 1.0);
        normalMap.xy = normalMed * (0.075 * WATER_BUMP_MED)
                     + normalBig * (0.042 * WATER_BUMP_BIG)
                     + normalSmall * (0.020 * WATER_BUMP_SMALL)
                     + luminaraEvolvingSlope;

        float luminaraDistanceFade = mix(1.0, 0.38, smoothstep(32.0, 176.0, lViewPos));
        float luminaraLightWave = 0.42 + 0.58 * lmCoordM.y;
        float luminaraRainWave = 1.0 + 0.18 * rainFactor * inRainy;
        normalMap.xy *= WATER_BUMPINESS * luminaraDistanceFade * luminaraLightWave * luminaraRainWave;
        normalMap.z = sqrt(max(1.0 - dot(normalMap.xy, normalMap.xy), 0.02));
        normalM = clamp(normalize(normalMap * tbnMatrix), vec3(-1.0), vec3(1.0));

        vec3 luminaraReflectedView = reflect(nViewPos, normalize(normalM));
        float luminaraNormalRepair = pow2(pow2(pow2(1.0 - max0(dot(normal, luminaraReflectedView))))) * 0.5;
        normalM = mix(normalM, normal, luminaraNormalRepair);
        fresnel = clamp(1.0 + dot(normalM, nViewPos), 0.0, 1.0);
        fresnel2 = pow2(fresnel);
        fresnel4 = pow2(fresnel2);
    #endif

    #if WATER_MAT_QUALITY >= 2
        if (isEyeInWater != 1) {
            #ifdef GBUFFERS_WATER
                float depthT = texelFetch(depthtex1, texelCoord, 0).r;
            #elif defined DH_WATER
                float depthT = texelFetch(dhDepthTex1, texelCoord, 0).r;
            #endif

            vec3 screenPosT = vec3(screenPos.xy, depthT);
            #ifdef TAA
                vec3 viewPosT = ScreenToView(vec3(TAAJitter(screenPosT.xy, -0.5), screenPosT.z));
            #else
                vec3 viewPosT = ScreenToView(screenPosT);
            #endif

            float lViewPosT = length(viewPosT);
            float luminaraWaterThickness = max(lViewPosT - lViewPos, 0.0);
            if (depthT >= 0.99999) luminaraWaterThickness = max(luminaraWaterThickness, 48.0);

            float luminaraFogScale = float(WATER_FOG_MULT) * 0.01;
            float waterFog = 1.0 - exp(-luminaraWaterThickness * 0.075 * luminaraFogScale);
            waterFog = clamp(waterFog, 0.0, 1.0);

            vec3 luminaraBiomeWater = mix(vec3(1.0), luminaraBiomeTint * vec3(0.88, 1.04, 1.10), 0.27);
            vec3 luminaraShallowColor = vec3(0.080, 0.330, 0.355) * luminaraBiomeWater;
            vec3 luminaraDeepColor = vec3(0.018, 0.095, 0.175) * mix(vec3(1.0), luminaraBiomeWater, 0.55);
            float luminaraSurfaceVariation = dot(normalMed, vec2(0.62, 0.38)) * 0.055;

            color.rgb = mix(luminaraShallowColor, luminaraDeepColor, smoothstep(0.04, 0.96, waterFog));
            color.rgb *= luminaraWaterControl;
            color.rgb *= (0.82 + 0.22 * lmCoordM.y + luminaraSurfaceVariation);

            color.a = mix(0.10, 0.86, waterFog);
            #if WATER_ALPHA_MULT != 100
                #define LUMINARA_WATER_ALPHA_POWER 100.0 / WATER_ALPHA_MULT
                color.a = pow(color.a, LUMINARA_WATER_ALPHA_POWER);
            #endif

            #ifdef DISTANT_HORIZONS
                if (depthT == 1.0) color.a *= smoothstep(far, far * 0.90, lViewPos);
            #endif

            #ifdef GBUFFERS_WATER
                translucentMultCalculated = true;
                vec3 luminaraAbsorption = vec3(0.105, 0.038, 0.020);
                translucentMult.rgb = exp(-luminaraAbsorption * min(luminaraWaterThickness, 48.0));
                translucentMult.rgb = mix(translucentMult.rgb, luminaraDeepColor * 2.2, waterFog * 0.28);
            #endif

            // Foam exists only where the water intersects shallow geometry.
            #if WATER_FOAM_I > 0 && defined GBUFFERS_WATER
                if (NdotU > 0.99) {
                    vec3 luminaraUpRow = vec3(
                        gbufferModelViewInverse[0].y,
                        gbufferModelViewInverse[1].y,
                        gbufferModelViewInverse[2].y
                    );
                    float luminaraBottomY = dot(luminaraUpRow, viewPosT) + gbufferModelViewInverse[3].y;
                    float luminaraShoreDepth = max(playerPos.y - luminaraBottomY, 0.0);
                    float luminaraShoreMask = 1.0 - smoothstep(0.055, 1.15, luminaraShoreDepth);

                    #if WATER_STYLE >= 2
                        float luminaraFoamNoise = texture2D(gaux4, luminaraCoordA * 1.73).r * 0.62
                                                 + texture2D(gaux4, luminaraCoordC * 0.51).g * 0.38;
                    #else
                        float luminaraFoamNoise = texture2D(noisetex, waterPos * 4.0
                                                 + luminaraWaterTime * vec2(0.7, -0.4)).g;
                    #endif
                    float luminaraFoamBreakup = smoothstep(0.51, 0.74,
                        luminaraFoamNoise + luminaraShoreMask * 0.17 + rainFactor * inRainy * 0.04);
                    float luminaraSurfaceBand = clamp((fract(worldPos.y) - 0.70) * 10.0, 0.0, 1.0);
                    float luminaraFoam = luminaraShoreMask * luminaraFoamBreakup * luminaraSurfaceBand;
                    luminaraFoam *= float(WATER_FOAM_I) * 0.01;

                    vec3 luminaraFoamColor = mix(vec3(0.76, 0.90, 0.89), vec3(0.96, 0.99, 0.98), lmCoordM.y);
                    color.rgb = mix(color.rgb, luminaraFoamColor, min(luminaraFoam, 0.92));
                    color.a = max(color.a, luminaraFoam * 0.78);
                    reflectMult *= 1.0 - min(luminaraFoam * 0.72, 0.72);
                }
            #endif
        } else {
            noDirectionalShading = true;
            reflectMult = 0.32;

            #ifdef GBUFFERS_WATER
                translucentMult.rgb *= 1.0 - 0.72 * max(0.45 * sqrt(fresnel4), fresnel4);
            #endif
        }
    #else
        color.a = sqrt(max(color.a, 0.0)) * 0.58;
        shadowMult = vec3(0.0);
    #endif

    // Water reflects little when viewed straight down and strongly at grazing angles.
    reflectMult *= mix(0.18, 1.0, fresnel2) * (0.55 + 0.45 * NdotUmax0);
    color.a = mix(color.a, 1.0, fresnel4);

    #ifdef GBUFFERS_WATER
        #if WATER_STYLE >= 2
            smoothnessG = 0.96;
            float luminaraHighlight = max0(dot(normalM, lightVec));
            luminaraHighlight /= max(dot(normal, lightVec), 0.18);
            highlightMult = pow2(pow2(min(luminaraHighlight, 1.35))) * 0.17;
        #else
            smoothnessG = 0.55;
            highlightMult = min(pow2(dot(colorP.rgb, colorP.rgb) * 0.35), 0.35);
        #endif
    #endif
#endif
