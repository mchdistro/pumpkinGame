// Volumetric caustic lighting system | نظام إضاءة كاستيك حجمي
#define WATER_CAUSTIC_STYLE_DEFINE 3 // [1 2 3]
// Advanced underwater view distortion | تشويه رؤية واقعي تحت الماء
#define UNDERWATER_DISTORTION


// Underwater red channel intensity | شدة القناة الحمراء تحت الماء
#define UNDERWATERCOLOR_R 85
// Advanced water color mode selection | اختيار وضع لون مياه متقدم
#define WATERCOLOR_MODE 3
// Underwater blue channel saturation | تشبع القناة الزرقاء تحت الماء  
#define UNDERWATERCOLOR_B 112


// Wave velocity multiplier control | تحكم مضاعف سرعة الأمواج
#define WATER_SPEED_MULT 1.00 // [0.50 0.75 1.00 1.25 1.50]
// Large scale wave displacement | إزاحة موجية واسعة النطاق
#define WATER_BUMP_BIG 1.20


// Premium water surface rendering mode | وضع تصيير سطح مائي متميز
#define WATER_STYLE_DEFINE 3 // [1 2 3]
// Water foam intensity control | تحكم شدة رغوة الماء
#define WATER_FOAM_I 80 // [0 50 80 100 120 150]


// Rain-enhanced waving multiplier | مضاعف تمايل محسن بالمطر
#define WAVING_I_RAIN_MULT 100
// Botanical leaf dynamics | ديناميكيات الأوراق النباتية
#define WAVING_LEAVES
// Aquatic vegetation animation | رسوم متحركة للنباتات المائية
#define WAVING_LILY_PAD
// Advanced lava flow simulation | محاكاة تدفق حمم متقدمة
#define WAVING_LAVA
// Motion intensity controller | متحكم شدة الحركة
#define WAVING_I 1.00


// Surface roughness master control | تحكم رئيسي في خشونة السطح
#define WATER_BUMPINESS 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]
// Water red channel intensity | شدة القناة الحمراء للماء
#define WATERCOLOR_R 100
// Environmental animation speed | سرعة الرسوم المتحركة البيئية
#define WAVING_SPEED 1.00


// Water green channel saturation | تشبع القناة الخضراء للماء
#define WATERCOLOR_G 105
// Underwater green channel intensity | شدة القناة الخضراء تحت الماء
#define UNDERWATERCOLOR_G 105
// Water blue channel vibrancy | حيوية القناة الزرقاء للماء
#define WATERCOLOR_B 115


// Precipitation response system | نظام استجابة للهطول
#define WAVING_RAIN
// Indoor motion suppression | قمع الحركة الداخلية
#define NO_WAVING_INDOORS
// Enhanced cave water lighting | إضاءة محسنة لمياه الكهوف
#define BRIGHT_CAVE_WATER
// Vegetation dynamics system | نظام ديناميكيات النباتات
#define WAVING_FOLIAGE


// Transparency modulation factor | عامل تعديل الشفافية
#define WATER_ALPHA_MULT 100 // [70 85 100 115 130]
// Medium wave pattern control | تحكم نمط الأمواج المتوسطة
#define WATER_BUMP_MED 1.00
// Vertex-level water animation | رسوم متحركة للماء على مستوى الرؤوس
#define WAVING_WATER_VERTEX
// Refractive index controller | متحكم معامل الانكسار
#define WATER_REFRACTION_INTENSITY 1.25 // [0.50 0.75 1.00 1.25 1.50 2.00]

// Atmospheric fog density multiplier | مضاعف كثافة الضباب الجوي
#define WATER_FOG_MULT 100 // [70 85 100 115 130]
// Wave scale enhancement factor | عامل تحسين مقياس الأمواج
#define WATER_SIZE_MULT 100 // [60 80 100 125 150]
// Fine detail wave control | تحكم تفاصيل الأمواج الدقيقة
#define WATER_BUMP_SMALL 0.75
