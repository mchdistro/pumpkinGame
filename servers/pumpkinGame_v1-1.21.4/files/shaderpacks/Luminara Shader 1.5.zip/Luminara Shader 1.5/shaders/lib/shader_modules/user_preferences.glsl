
// Advanced shadow rendering quality | جودة تصيير الظلال المتقدمة
#define SHADOW_QUALITY 2 // [-1 0 1 2 3 4 5]
// Shadow distance optimization | تحسين مسافة الظلال
const float shadowDistance = 192.0; // [64.0 96.0 128.0 160.0 192.0 256.0]
// Professional cloud rendering quality | جودة تصيير السحب الاحترافية
#define CLOUD_QUALITY 3 // [0 1 2 3]
// Block reflection quality control | تحكم جودة انعكاس الكتل
#define BLOCK_REFLECT_QUALITY 3 // [0 1 2 3]


// Master shader style selector | محدد نمط الشيدر الرئيسي
#define SHADER_STYLE 1
// Rendering pipeline mode | وضع خط أنابيب التصيير
#define RP_MODE 1
// Detail quality enhancement | تحسين جودة التفاصيل
#define DETAIL_QUALITY 2 // [0 1 2 3]


// Colored lighting system control | تحكم نظام الإضاءة الملونة
#define COLORED_LIGHTING 0
#if defined IRIS_FEATURE_CUSTOM_IMAGES && SHADOW_QUALITY > -1 && !defined MC_OS_MAC && !(defined DH_TERRAIN || defined DH_WATER)
    #define COLORED_LIGHTING_INTERNAL COLORED_LIGHTING
    #if COLORED_LIGHTING_INTERNAL > 0
        // Color saturation enhancement | تحسين تشبع الألوان
        #define COLORED_LIGHT_SATURATION 100
        // Advanced fog lighting effects | تأثيرات إضاءة الضباب المتقدمة
        #define COLORED_LIGHT_FOG
        // Fog lighting intensity | شدة إضاءة الضباب
        #define COLORED_LIGHT_FOG_I 0.65
        // Dimensional portal edge effects | تأثيرات حافة البوابة البعدية
        #define PORTAL_EDGE_EFFECT
        #ifndef IRIS_HAS_CONNECTED_TEXTURES
            // Connected glass visual effects | تأثيرات بصرية للزجاج المتصل
            #define CONNECTED_GLASS_EFFECT
        #endif
    #endif
#else
    #define COLORED_LIGHTING_INTERNAL 0
#endif


// Nether dimension view distance | مسافة الرؤية في بعد العالم السفلي
#define NETHER_VIEW_LIMIT 99999.0
// Advanced Nether storm system | نظام عاصفة العالم السفلي المتقدم
#define NETHER_STORM
// Storm altitude control | تحكم ارتفاع العاصفة
#define NETHER_STORM_LOWER_ALT 28
// Storm intensity modulator | مُعدِّل شدة العاصفة
#define NETHER_STORM_I 0.40


// Aurora visibility system | نظام رؤية الشفق القطبي
#define AURORA_STYLE_DEFINE -1
// Aurora environmental conditions | الظروف البيئية للشفق القطبي
#define AURORA_CONDITION 3
// Enhanced stellar density | كثافة نجمية محسنة
#define NIGHT_STAR_AMOUNT 3
// Random shooting stars at night
#define SHOOTING_STARS
// Shooting-star appearance rate
#define METEOR_FREQUENCY 100 // [50 75 100 125 150 200]
// Shooting-star luminance
#define METEOR_BRIGHTNESS 100 // [50 75 100 125 150 200]
// Atmospheric rainbow effects | تأثيرات قوس قزح الجوية
#define RAINBOWS 1


// Fast approximate anti-aliasing | مكافحة التعرج التقريبية السريعة
#define FXAA_DEFINE 1 // [0 1]
// Shadow smoothing quality | جودة تنعيم الظلال
#define SHADOW_SMOOTHING 4 // [0 1 2 3 4]
// Entity shadow rendering | تصيير ظلال الكيان
#define ENTITY_SHADOWS_DEFINE -1


// Selection outline mode | وضع محيط التحديد
#define SELECT_OUTLINE 1
// Outline intensity control | تحكم شدة المحيط
#define SELECT_OUTLINE_I 1.00
// RGB color channel control | تحكم قنوات الألوان RGB
#define SELECT_OUTLINE_R 1.35
#define SELECT_OUTLINE_G 0.35
#define SELECT_OUTLINE_B 1.75


// Moon phase reflection influence | تأثير أطوار القمر على الانعكاس
#define MOON_PHASE_INF_REFLECTION
// Full moon lighting intensity | شدة إضاءة البدر
#define MOON_PHASE_FULL 1.00
// Partial moon phase intensity | شدة الطور الجزئي للقمر
#define MOON_PHASE_PARTIAL 0.85


// Dynamic border fog system | نظام الضباب الحدودي الديناميكي
#define BORDER_FOG
    // Nether environment fog optimization | تحسين ضباب بيئة العالم السفلي
    #ifdef NETHER
        #undef BORDER_FOG
    #endif
// Atmospheric fog multiplier | مضاعف الضباب الجوي
#define ATM_FOG_MULT 0.65
// Fog distance control | تحكم مسافة الضباب
#define ATM_FOG_DISTANCE 130
// Cave atmospheric fog | ضباب جوي للكهوف
#define CAVE_FOG


// Particle density reduction | تقليل كثافة الجسيمات
#define REDUCE_CLOSE_PARTICLES
// Lava fog intensity reduction | تقليل شدة ضباب الحمم
#define LESS_LAVA_FOG
// Anisotropic filtering quality | جودة التصفية متباينة الخواص
#define ANISOTROPIC_FILTER 0


// Hand movement animation | رسوم متحركة لحركة اليد
#define HAND_SWAYING 0
// Light level visualization | تصور مستوى الضوء
#define SHOW_LIGHT_LEVEL 0
// Solar positioning control | تحكم موضع الشمس
#define SUN_ANGLE -1


// Water reflection quality | جودة انعكاس الماء
#define WATER_REFLECT_QUALITY 2 // [-1 0 1 2]
// Rain puddle rendering | تصيير برك المطر
#define RAIN_PUDDLES 0


// SSAO quality control | تحكم جودة SSAO
#define SSAO_QUALI_DEFINE 2 // [0 1 2]
// SSAO intensity | شدة SSAO
#define SSAO_I 100
// Vanilla AO intensity | شدة AO الفانيليا
#define VANILLAAO_I 100


// Light shaft behavior mode | وضع سلوك عمود الضوء
#define LIGHTSHAFT_BEHAVIOUR 1
// Light shaft quality definition | تعريف جودة عمود الضوء
#define LIGHTSHAFT_QUALI_DEFINE 0
// Day light shaft intensity | شدة عمود الضوء النهاري
#define LIGHTSHAFT_DAY_I 100
// Night light shaft enhancement | تحسين عمود الضوء الليلي
#define LIGHTSHAFT_NIGHT_I 100


// Weather texture opacity | شفافية نسيج الطقس
#define WEATHER_TEX_OPACITY 100
// Rain rendering style | نمط تصيير المطر
#define RAIN_STYLE 1
// Rain light shaft intensity | شدة عمود الضوء المطري
#define LIGHTSHAFT_RAIN_I 100


// World outline thickness control | تحكم سمك محيط العالم
#define WORLD_OUTLINE_THICKNESS 1
// World outline intensity | شدة محيط العالم
#define WORLD_OUTLINE_I 1.50
// Entity outline rendering | تصيير محيط الكيان
#define WORLD_OUTLINE_ON_ENTITIES
// Dark outline enhancement | تحسين المحيط المظلم
#define DARK_OUTLINE_THICKNESS 1


// Celestial object style | نمط الأجرام السماوية
#define SUN_MOON_STYLE_DEFINE -1
// Horizon celestial visibility | رؤية الأجرام السماوية في الأفق
#define SUN_MOON_HORIZON
// Celestial visibility during rain | رؤية الأجرام السماوية أثناء المطر
#define SUN_MOON_DURING_RAIN


// Nether color mode selection | اختيار وضع ألوان العالم السفلي
#define NETHER_COLOR_MODE 3
// Nether storm height control | تحكم ارتفاع عاصفة العالم السفلي
#define NETHER_STORM_HEIGHT 200
// Atmospheric fog altitude | ارتفاع الضباب الجوي
#define ATM_FOG_ALTITUDE 70

// Nether-specific light shaft optimization | تحسين عمود الضوء الخاص بالعالم السفلي
#ifdef NETHER
    #undef LIGHTSHAFT_DAY_I
    #undef LIGHTSHAFT_NIGHT_I
    #undef LIGHTSHAFT_RAIN_I
    #define LIGHTSHAFT_DAY_I 25
    #define LIGHTSHAFT_NIGHT_I 25
    #define LIGHTSHAFT_RAIN_I 25
#endif


// Dark moon phase intensity | شدة طور القمر المظلم
#define MOON_PHASE_DARK 0.60
// Nebula intensity control | تحكم شدة السديم
#define NIGHT_NEBULA_I 120


// Pixel scale enhancement | تحسين مقياس البكسل
#define PIXEL_SCALE 1

// Biome color grading | تدرج ألوان البايوم
#define BIOME_COLOR_GRADING 1 // [0 1]
