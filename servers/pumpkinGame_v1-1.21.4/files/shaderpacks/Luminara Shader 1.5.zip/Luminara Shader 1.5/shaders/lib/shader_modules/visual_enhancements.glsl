
// Professional bloom strength control | تحكم قوة الإزهار الاحترافي
#define BLOOM_STRENGTH 0.054 // [0.020 0.035 0.054 0.075 0.100]
// Master bloom activation system | نظام تفعيل الإزهار الرئيسي
#define BLOOM
// Advanced distance light effects | تأثيرات الضوء البعيد المتقدمة
#define DISTANT_LIGHT_BOKEH

// Intelligent image sharpening | شحذ الصورة الذكي
#define IMAGE_SHARPENING 5 // [0 1 2 3 4 5]
// Motion blur intensity controller | متحكم شدة ضبابية الحركة
#define MOTION_BLURRING_STRENGTH 1.00
// Professional vignette effect | تأثير تظليل احترافي
#define VIGNETTE_R
// Chromatic aberration intensity | شدة الانحراف اللوني
#define CHROMA_ABERRATION 0
// Lens flare rendering mode | وضع تصيير توهج العدسة
#define LENSFLARE_MODE 0
// Lens flare intensity control | تحكم شدة توهج العدسة
#define LENSFLARE_I 1.00
// Temporal AA processing mode | وضع معالجة AA الزمني
#define TAA_MODE 1 // [0 1]

// World blur mode selection | اختيار وضع ضبابية العالم
#define WORLD_BLUR 0
// Depth of field intensity | شدة عمق المجال
#define WB_DOF_I 64.0
// Focus distance controller | متحكم مسافة التركيز
#define WB_DOF_FOCUS 0
// Day environment blur | ضبابية بيئة النهار
#define WB_DB_DAY_I 64.0
// Night environment enhancement | تحسين بيئة الليل
#define WB_DB_NIGHT_I 64.0
// Rain weather blur system | نظام ضبابية طقس المطر
#define WB_DB_RAIN_I 64.0
// Underwater depth effects | تأثيرات العمق تحت الماء
#define WB_DB_WATER_I 64.0
// Nether dimension blur control | تحكم ضبابية بعد العالم السفلي
#define WB_DB_NETHER_I 64.0
// Enhanced depth blur for End dimension | ضبابية عمق محسنة لبعد النهاية
#define WB_DB_END_I 128.0

// Exposure control master | متحكم التعرض الرئيسي
#define T_EXPOSURE 1.40
// White point curve adjustment | تعديل منحنى النقطة البيضاء
#define TM_WHITE_CURVE 2.0
// Lower tone curve control | تحكم منحنى النغمات المنخفضة
#define T_LOWER_CURVE 1.10
// Upper tone curve enhancement | تحسين منحنى النغمات العليا
#define T_UPPER_CURVE 1.30
// Saturation curve control | تحكم منحنى التشبع
#define T_SATURATION 1.00
// Color vibrance enhancement | تحسين حيوية الألوان
#define T_VIBRANCE 1.00

//Color Grading//
    //#define COLORGRADING
    #define GR_RR 100
    #define GR_RG 0
    #define GR_RB 0
    #define GR_RC 1.00
    #define GR_GR 0
    #define GR_GG 100
    #define GR_GB 0
    #define GR_GC 1.00
    #define GR_BR 0
    #define GR_BG 0
    #define GR_BB 100
    #define GR_BC 1.00
