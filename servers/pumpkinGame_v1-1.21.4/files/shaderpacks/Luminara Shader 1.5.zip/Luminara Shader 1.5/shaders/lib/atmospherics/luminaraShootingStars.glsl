#ifndef INCLUDE_LUMINARA_SHOOTING_STARS
#define INCLUDE_LUMINARA_SHOOTING_STARS

// Deterministic event noise. Each time slot receives a completely new meteor.
float LuminaraMeteorHash(float seed) {
    return fract(sin(seed * 127.1 + 311.7) * 43758.5453123);
}

// Draws short-lived shooting stars in a tangent plane on the celestial sphere.
// The tangent projection keeps the trail width stable and prevents stretching.
vec3 GetLuminaraShootingStars(vec3 viewPos, float VdotU) {
    #ifndef SHOOTING_STARS
        return vec3(0.0);
    #else
        if (VdotU <= 0.02) return vec3(0.0);

        vec3 skyDirection = normalize(mat3(gbufferModelViewInverse) * viewPos);

        float nightVisibility = pow2(pow2(invNoonFactor2));
        nightVisibility *= 1.0 - sunVisibility;
        nightVisibility *= invRainFactor;
        nightVisibility *= smoothstep(0.03, 0.24, VdotU);
        nightVisibility *= 1.0 - maxBlindnessDarkness;

        if (nightVisibility <= 0.001) return vec3(0.0);

        float frequency = max(float(METEOR_FREQUENCY) * 0.01, 0.25);
        float eventInterval = 9.0 / frequency;
        float brightness = float(METEOR_BRIGHTNESS) * 0.01;
        vec3 meteorLight = vec3(0.0);

        // Three staggered event streams make appearances irregular without state.
        for (int stream = 0; stream < 3; stream++) {
            float streamId = float(stream);
            float streamTime = frameTimeCounter + streamId * eventInterval * 0.371
                                             + streamId * 17.173;
            float eventIndex = floor(streamTime / eventInterval);
            float eventTime = mod(streamTime, eventInterval);
            float seed = eventIndex + streamId * 97.31;

            float eventRoll = LuminaraMeteorHash(seed + 4.13);
            float duration = mix(0.80, 1.42, LuminaraMeteorHash(seed + 8.71));

            // Some slots remain empty, producing natural pauses between meteors.
            if (eventRoll > 0.38 && eventTime < duration) {
                float phase = clamp(eventTime / duration, 0.0, 1.0);
                float envelope = smoothstep(0.0, 0.075, phase)
                               * (1.0 - smoothstep(0.72, 1.0, phase));

                float yaw = LuminaraMeteorHash(seed + 12.41) * 2.0 * pi;
                float elevation = mix(0.30, 1.12, LuminaraMeteorHash(seed + 18.93));
                float cosElevation = cos(elevation);

                vec3 eventForward = vec3(cos(yaw) * cosElevation,
                                         sin(elevation),
                                         sin(yaw) * cosElevation);
                vec3 eventRight = vec3(-sin(yaw), 0.0, cos(yaw));
                vec3 eventUp = normalize(cross(eventRight, eventForward));

                float facing = dot(skyDirection, eventForward);
                if (facing > 0.30) {
                    vec2 projectedDirection = vec2(dot(skyDirection, eventRight),
                                                   dot(skyDirection, eventUp)) / facing;

                    float sideSign = LuminaraMeteorHash(seed + 25.77) > 0.5 ? 1.0 : -1.0;
                    vec2 travelDirection = normalize(vec2(
                        sideSign * mix(0.62, 1.0, LuminaraMeteorHash(seed + 29.17)),
                        -mix(0.28, 0.78, LuminaraMeteorHash(seed + 33.53))
                    ));

                    float travelSpan = mix(0.28, 0.52, LuminaraMeteorHash(seed + 39.11));
                    vec2 headPosition = travelDirection * mix(-0.52 * travelSpan,
                                                               0.48 * travelSpan,
                                                               phase);

                    vec2 fromHead = projectedDirection - headPosition;
                    vec2 trailDirection = -travelDirection;
                    vec2 trailNormal = vec2(-trailDirection.y, trailDirection.x);
                    float alongTrail = dot(fromHead, trailDirection);
                    float acrossTrail = abs(dot(fromHead, trailNormal));

                    float trailLength = mix(0.105, 0.225, LuminaraMeteorHash(seed + 43.89));
                    float trailPosition = clamp(alongTrail / trailLength, 0.0, 1.0);
                    float segmentMask = step(0.0, alongTrail) * step(alongTrail, trailLength);
                    float trailTaper = pow(1.0 - trailPosition, 0.72) * segmentMask;

                    float trailWidth = mix(0.00135, 0.00215,
                                           LuminaraMeteorHash(seed + 47.27));
                    float hotTrail = (1.0 - smoothstep(trailWidth * 0.20,
                                                       trailWidth, acrossTrail))
                                   * trailTaper;
                    float trailGlow = (1.0 - smoothstep(trailWidth,
                                                        trailWidth * 5.8, acrossTrail))
                                    * trailTaper * trailTaper;

                    float headDistance = length(fromHead);
                    float hotHead = 1.0 - smoothstep(trailWidth * 0.25,
                                                     trailWidth * 2.25,
                                                     headDistance);
                    float headGlow = 1.0 - smoothstep(trailWidth * 1.5,
                                                      trailWidth * 10.0,
                                                      headDistance);

                    float colorRandom = LuminaraMeteorHash(seed + 55.63);
                    vec3 trailColor = mix(vec3(0.58, 0.76, 1.00),
                                          vec3(1.00, 0.72, 0.40),
                                          colorRandom);
                    vec3 headColor = mix(trailColor, vec3(1.0, 0.97, 0.90), 0.72);
                    float intensityRandom = mix(0.72, 1.35,
                                                LuminaraMeteorHash(seed + 61.07));

                    vec3 eventLight = trailColor * (hotTrail * 3.8 + trailGlow * 0.78)
                                    + headColor * (hotHead * 8.5 + headGlow * 1.35);
                    meteorLight += eventLight * envelope * intensityRandom;
                }
            }
        }

        return meteorLight * nightVisibility * brightness;
    #endif
}

#endif
