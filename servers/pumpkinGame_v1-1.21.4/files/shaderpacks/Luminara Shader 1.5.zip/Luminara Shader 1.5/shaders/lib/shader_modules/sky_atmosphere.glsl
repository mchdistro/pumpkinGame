
// Celestial body visibility during precipitation | رؤية الأجرام السماوية أثناء الهطول
#define SUN_MOON_DURING_RAIN
// Horizon-enhanced celestial rendering | تصيير سماوي محسن للأفق
#define SUN_MOON_HORIZON
// Professional celestial object style | نمط أجرام سماوية احترافي
#define SUN_MOON_STYLE_DEFINE -1


// Enhanced stellar density control | تحكم كثافة نجمية محسن
#define NIGHT_STAR_AMOUNT 3
// Nebula intensity modulator | مُعدِّل شدة السديم
#define NIGHT_NEBULA_I 120


// Weather texture opacity controller | متحكم شفافية نسيج الطقس
#define WEATHER_TEX_OPACITY 100
// Precipitation rendering mode | وضع تصيير الهطول
#define RAIN_STYLE 1
// Optical atmospheric effects | تأثيرات جوية بصرية
#define RAINBOWS 1


// Dynamic cloud shadow casting | إلقاء ظلال السحب الديناميكي
#define CLOUD_SHADOWS
// Advanced cloud area detection | كشف منطقة السحب المتقدم
#define CLOUD_CLOSED_AREA_CHECK
// Cloud blue channel vibrancy | حيوية القناة الزرقاء للسحب
#define CLOUD_B 115


// Cloud scale enhancement multiplier | مضاعف تحسين مقياس السحب
#define CLOUD_UNBOUND_SIZE_MULT 140
// Weather-responsive cloud density | كثافة سحب مستجيبة للطقس
#define CLOUD_UNBOUND_RAIN_ADD 0.75


// Cloud green channel saturation | تشبع القناة الخضراء للسحب  
#define CLOUD_G 110
// Atmospheric movement velocity | سرعة الحركة الجوية
#define CLOUD_SPEED_MULT 85
// Professional cloud style selector | محدد نمط السحب الاحترافي
#define CLOUD_STYLE_DEFINE 3


// Aurora visibility conditions | شروط رؤية الشفق القطبي
#define AURORA_CONDITION 3
// Aurora rendering style control | تحكم نمط تصيير الشفق القطبي
#define AURORA_STYLE_DEFINE -1


// Enhanced atmospheric depth fog | ضباب عمق جوي محسن
#define ATMOSPHERIC_FOG
// Conditional bloom fog system | نظام ضباب الإزهار المشروط
#define BLOOM_FOG
    // Advanced Nether environment optimization | تحسين بيئة العالم السفلي المتقدم
    #ifdef NETHER
        #undef BLOOM_FOG
    #endif


// Volumetric cloud density control | تحكم كثافة السحب الحجمية
#define CLOUD_UNBOUND_AMOUNT 1.3
// Cloud red channel warmth | دفء القناة الحمراء للسحب
#define CLOUD_R 105
