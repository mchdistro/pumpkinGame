
// Enhanced redstone block emission | انبعاث محسن لكتلة الريدستون
#define EMISSIVE_REDSTONE_BLOCK
// Advanced amethyst glow system | نظام توهج الجمشت المتقدم
#define GLOWING_AMETHYST 2
// Custom emission intensity control | تحكم شدة الانبعاث المخصص
#define CUSTOM_EMISSION_INTENSITY 40


// POM surface detail depth control | تحكم عمق تفاصيل سطح POM
#define POM_DEPTH 0.80
// Advanced lighting calculation mode | وضع حساب الإضاءة المتقدم
#define POM_LIGHTING_MODE 2
// Distance-based quality optimization | تحسين الجودة القائم على المسافة
#define POM_DISTANCE 32


// Underground illumination enhancement | تحسين الإضاءة تحت الأرض
#define CAVE_LIGHTING 100
// Dynamic light flicker simulation | محاكاة وميض الضوء الديناميكي
#define BLOCKLIGHT_FLICKERING 0
// Held item illumination mode | وضع إضاءة العنصر المحمول
#define HELD_LIGHTING_MODE 2


// Master ore glow controller | متحكم توهج الخامات الرئيسي
#define GLOWING_ORE_MASTER 2
// Advanced lichen luminescence | توهج الأشنة المتقدم
#define GLOWING_LICHEN 2
// Ore glow intensity multiplier | مضاعف شدة توهج الخامات
#define GLOWING_ORE_MULT_BASE 0.25
// Dynamic ore glow with flickering effect | توهج خامات ديناميكي مع تأثير الوميض
#define GLOWING_ORE_MULT (GLOWING_ORE_MULT_BASE * getOreFlickerMultiplier(playerPos + cameraPosition, frameTimeCounter))

#if GLOWING_ORE_MASTER == 2 || SHADER_STYLE == 4 && GLOWING_ORE_MASTER == 1
    // Precious metal ore illumination | إضاءة خامات المعادن الثمينة
    #define GLOWING_ORE_GOLD
    #define GLOWING_ORE_DIAMOND
    #define GLOWING_ORE_EMERALD
    // Base metal ore enhancement | تحسين خامات المعادن الأساسية  
    #define GLOWING_ORE_IRON
    #define GLOWING_ORE_COPPER
    // Functional ore highlighting | إبراز الخامات الوظيفية
    #define GLOWING_ORE_REDSTONE
    #define GLOWING_ORE_LAPIS
    // Nether realm ore control | تحكم خامات عالم الجحيم
    #define GLOWING_ORE_GILDEDBLACKSTONE
    // Modded content compatibility | توافق المحتوى المعدل
    #define GLOWING_ORE_MODDED
#endif


// Generated normal map intensity | شدة خريطة العادي المولدة
#define GENERATED_NORMAL_MULT 100
// Normal mapping strength control | تحكم قوة خرائط العادي
#define NORMAL_MAP_STRENGTH 100
// Entity normal generation system | نظام توليد عادي الكيان
#define ENTITY_GN_AND_CT


// Advanced portal visual effects | تأثيرات بصرية متقدمة للبوابات
#define SPECIAL_PORTAL_EFFECTS


// Coated texture enhancement multiplier | مضاعف تحسين النسيج المطلي
#define COATED_TEXTURE_MULT 100
// Lapis lazuli block emission | انبعاث كتلة اللازورد
#define EMISSIVE_LAPIS_BLOCK
// Glass transparency control | تحكم شفافية الزجاج
#define GLASS_OPACITY 0.25


// Shadow frustum fitting algorithm | خوارزمية ملائمة مخروط الظل
#define SHADOW_FRUSTUM_FIT
// Entity glow stability fix | إصلاح استقرار توهج الكيان
#define GLOWING_ENTITY_FIX
// Light flickering correction | تصحيح وميض الضوء
#define FLICKERING_FIX


// High-quality shadow filtering | تصفية ظلال عالية الجودة
#define SHADOW_FILTERING
// Advanced directional shading | تظليل اتجاهي متقدم
#define DIRECTIONAL_SHADING
// Environmental side shadowing | تظليل جانبي بيئي
#define SIDE_SHADOWING
// Player shadow casting mode | وضع إلقاء ظل اللاعب
#define PLAYER_SHADOW 1


// Ambient illumination multiplier | مضاعف الإضاءة المحيطة
#define AMBIENT_MULT 100
// PBR emission processing mode | وضع معالجة انبعاث PBR
#define IPBR_EMISSIVE_MODE 1
// Directional block light control | تحكم الضوء الكتلي الاتجاهي
#define DIRECTIONAL_BLOCKLIGHT 0


// Advanced Nether emission reduction | تقليل انبعاث العالم السفلي المتقدم
#ifdef NETHER
    #define NETHER_EMISSION_REDUCTION 0.3
#else
    #define NETHER_EMISSION_REDUCTION 1.0
#endif


// POM rendering quality level | مستوى جودة تصيير POM
#define POM_QUALITY 128


// Ore flickering animation speed | سرعة رسوم وميض الخامات
#define ORE_FLICKER_SPEED 2.5

// Generate flickering multiplier for ore glow | توليد مضاعف الوميض لتوهج الخامات
float getOreFlickerMultiplier(vec3 worldPos, float time) {
    // Create unique seed based on world position | إنشاء بذرة فريدة بناء على موقع العالم
    float seed = dot(floor(worldPos * 0.1), vec3(12.9898, 78.233, 45.164));
    
    // Generate smooth flickering pattern | توليد نمط وميض ناعم
    float flicker1 = sin(time * ORE_FLICKER_SPEED + seed) * 0.5 + 0.5;
    float flicker2 = sin(time * ORE_FLICKER_SPEED * 1.7 + seed * 1.3) * 0.3 + 0.7;
    
    // Combine flickering patterns for natural effect | دمج أنماط الوميض للحصول على تأثير طبيعي
    float combinedFlicker = flicker1 * flicker2;
    
    // Apply smooth transitions | تطبيق انتقالات ناعمة
    return mix(0.3, 1.0, combinedFlicker);
}
